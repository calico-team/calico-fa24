def solve(N: int, H: int, D: int, S: int, P: int, L: int) -> int:
    """
    Return the number of healing items the player needs to use.
    
    N: starting health
    H: amount of healing
    D: distance out of the storm in meters
    S: running speed in meters per second
    P: storm damage per second
    L: time to heal
    """
    numerator = (D // S) * P - N
    return 0 if numerator < 0 else numerator // (H - (P * L)) + 1

def main():
    T = int(input())
    for _ in range(T):
        N, H, D, S, P, L = map(int, input().split())
        print(solve(N, H, D, S, P, L))

if __name__ == '__main__':
    main()